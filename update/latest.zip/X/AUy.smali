# classes6.dex

.class public final LX/AUy;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public A00:Landroid/view/ViewGroup$LayoutParams;

.field public A01:Landroid/view/ViewGroup;

.field public A02:Landroid/view/ViewGroup;

.field public A03:Landroid/view/ViewGroup;

.field public A04:Landroid/widget/ImageView;

.field public A05:Landroid/widget/ImageView;

.field public A06:Landroid/widget/ImageView;

.field public A07:Landroid/widget/ImageView;

.field public A08:Landroid/widget/ImageView;

.field public A09:Landroid/widget/ImageView;

.field public A0A:Landroid/widget/ImageView;

.field public A0B:Landroid/widget/LinearLayout;

.field public A0C:Landroid/widget/TextView;

.field public A0D:LX/AXb;

.field public A0E:Lcom/whatsapp/ui/coreui/base/WaTextView;

.field public A0F:Lcom/whatsapp/ui/coreui/base/WaTextView;

.field public A0G:LX/0Rh;

.field public A0H:LX/0Rh;

.field public A0I:LX/0Rh;

.field public A0J:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    return-void
.end method


# virtual methods
.method public final A00(Landroid/content/Context;Landroid/view/ViewGroup;IIZ)V
    .registers 11

    .line 0
    const/4 v4, 0x0

    .line 1
    invoke-static {p1, v4}, LX/00C;->A0A(Ljava/lang/Object;I)V

    .line 4
    if-eqz p5, :cond_38

    .line 6
    iget-object v3, p0, LX/AUy;->A0G:LX/0Rh;

    .line 8
    if-nez v3, :cond_18

    .line 10
    if-eqz p2, :cond_2f

    .line 12
    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_2f

    .line 18
    invoke-static {v0}, LX/1hB;->A13(Landroid/view/View;)LX/0Rh;

    .line 21
    move-result-object v3

    .line 22
    iput-object v3, p0, LX/AUy;->A0G:LX/0Rh;

    .line 24
    :cond_18
    invoke-static {v3}, LX/1hC;->A06(LX/0Rh;)Landroid/view/View;

    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Landroid/widget/ImageView;

    .line 30
    invoke-virtual {v2, p4}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 33
    const v0, 0x7f080241

    .line 36
    if-ne p4, v0, :cond_30

    .line 38
    const/4 v1, -0x1

    .line 39
    :goto_27
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 41
    invoke-virtual {v2, v1, v0}, Landroid/widget/ImageView;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    .line 44
    invoke-virtual {v3, v4}, LX/0Rh;->A05(I)V

    .line 47
    :cond_2f
    return-void

    .line 48
    :cond_30
    const v0, 0x7f0604c2

    .line 51
    invoke-static {p1, v0}, LX/04c;->A00(Landroid/content/Context;I)I

    .line 54
    move-result v1

    .line 55
    goto :goto_27

    .line 56
    :cond_38
    iget-object v0, p0, LX/AUy;->A0G:LX/0Rh;

    .line 58
    invoke-static {v0}, LX/1hK;->A17(LX/0Rh;)V

    .line 61
    return-void
.end method

.method public final A01(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/widget/TextView;LX/AUz;)V
    .registers 28

    .line 0
    const/4 v5, 0x0

    .line 1
    move-object/from16 v4, p1

    .line 3
    invoke-static {v4, v5}, LX/00C;->A0A(Ljava/lang/Object;I)V

    .line 6
    move-object/from16 v15, p0

    .line 8
    move-object/from16 v3, p2

    .line 10
    iput-object v3, v15, LX/AUy;->A01:Landroid/view/ViewGroup;

    .line 12
    move-object/from16 v7, p3

    .line 14
    iput-object v7, v15, LX/AUy;->A0C:Landroid/widget/TextView;

    .line 16
    move-object/from16 v2, p4

    .line 18
    if-eqz p3, :cond_2c

    .line 20
    iget-boolean v0, v2, LX/AUz;->A0M:Z

    .line 22
    if-eqz v0, :cond_555

    .line 24
    const/16 v0, 0x8

    .line 26
    invoke-virtual {v7, v0}, Landroid/view/View;->setVisibility(I)V

    .line 29
    :goto_1d
    iget-boolean v1, v2, LX/AUz;->A0Z:Z

    .line 31
    const v11, 0x7f0b0624

    .line 34
    iget v0, v2, LX/AUz;->A01:I

    .line 36
    move-object v8, v15

    .line 37
    move-object v9, v4

    .line 38
    move-object v10, v3

    .line 39
    move v12, v0

    .line 40
    move v13, v1

    .line 41
    invoke-virtual/range {v8 .. v13}, LX/AUy;->A00(Landroid/content/Context;Landroid/view/ViewGroup;IIZ)V

    .line 44
    :cond_2c
    if-eqz p2, :cond_427

    .line 46
    invoke-virtual {v3, v5}, Landroid/view/View;->setVisibility(I)V

    .line 49
    iget-boolean v0, v2, LX/AUz;->A0b:Z

    .line 51
    if-eqz v0, :cond_54e

    .line 53
    instance-of v0, v3, LX/D7C;

    .line 55
    if-eqz v0, :cond_54e

    .line 57
    iget-object v1, v15, LX/AUy;->A08:Landroid/widget/ImageView;

    .line 59
    if-nez v1, :cond_68

    .line 61
    new-instance v1, Landroid/widget/ImageView;

    .line 63
    invoke-direct {v1, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 66
    iput-object v1, v15, LX/AUy;->A08:Landroid/widget/ImageView;

    .line 68
    invoke-static {}, LX/1hE;->A09()Landroid/widget/LinearLayout$LayoutParams;

    .line 71
    move-result-object v6

    .line 72
    const/16 v0, 0x10

    .line 74
    iput v0, v6, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 76
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 79
    move-result-object v0

    .line 80
    invoke-static {v0}, LX/ASv;->A04(Landroid/content/res/Resources;)I

    .line 83
    move-result v0

    .line 84
    invoke-virtual {v6, v0}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 87
    invoke-virtual {v1, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 90
    iget-object v0, v15, LX/AUy;->A0C:Landroid/widget/TextView;

    .line 92
    invoke-virtual {v3, v0}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 95
    move-result v0

    .line 96
    add-int/lit8 v0, v0, 0x1

    .line 98
    invoke-virtual {v3, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 101
    invoke-virtual {v3, v5}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 104
    :cond_68
    iget-object v6, v2, LX/AUz;->A0H:LX/0wE;

    .line 106
    iget-boolean v11, v2, LX/AUz;->A0a:Z

    .line 108
    invoke-virtual {v6}, LX/0wE;->AsZ()I

    .line 111
    move-result v8

    .line 112
    const/16 v0, 0xd

    .line 114
    invoke-static {v8, v0}, LX/1dT;->A03(II)Z

    .line 117
    move-result v10

    .line 118
    if-nez v10, :cond_549

    .line 120
    const/4 v0, 0x5

    .line 121
    invoke-static {v8, v0}, LX/1dT;->A03(II)Z

    .line 124
    move-result v0

    .line 125
    if-nez v0, :cond_549

    .line 127
    const/4 v0, 0x4

    .line 128
    if-eq v8, v0, :cond_87

    .line 130
    const v9, 0x7f08088a

    .line 133
    if-eqz v11, :cond_8a

    .line 135
    :cond_87
    const v9, 0x7f08087d

    .line 138
    :cond_8a
    :goto_8a
    const v8, 0x7f0409c4

    .line 141
    const v0, 0x7f06088f

    .line 144
    if-eqz v10, :cond_98

    .line 146
    const v8, 0x7f0409db

    .line 149
    const v0, 0x7f0608a7

    .line 152
    :cond_98
    invoke-static {v4, v8, v0}, LX/0Qq;->A00(Landroid/content/Context;II)I

    .line 155
    move-result v0

    .line 156
    if-nez v0, :cond_543

    .line 158
    const/4 v0, 0x0

    .line 159
    :goto_9f
    invoke-static {v0, v1}, LX/0wt;->A00(Landroid/content/res/ColorStateList;Landroid/widget/ImageView;)V

    .line 162
    invoke-virtual {v1}, Landroid/view/View;->clearAnimation()V

    .line 165
    invoke-virtual {v1, v9}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 168
    invoke-virtual {v6}, LX/0wE;->AsZ()I

    .line 171
    move-result v9

    .line 172
    iget v8, v6, LX/0wE;->A0h:I

    .line 174
    const/16 v0, 0xd

    .line 176
    invoke-static {v9, v0}, LX/1dT;->A03(II)Z

    .line 179
    move-result v0

    .line 180
    if-eqz v0, :cond_52c

    .line 182
    if-nez v8, :cond_51d

    .line 184
    const v8, 0x7f121ea6

    .line 187
    :cond_bb
    :goto_bb
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 190
    move-result-object v0

    .line 191
    invoke-static {v0, v1, v8}, LX/1hD;->A1P(Landroid/content/Context;Landroid/view/View;I)V

    .line 194
    invoke-virtual {v1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 197
    invoke-static {v6}, LX/1Td;->A12(LX/0wE;)Z

    .line 200
    move-result v0

    .line 201
    if-eqz v0, :cond_d9

    .line 203
    invoke-virtual {v6}, LX/0wE;->AsZ()I

    .line 206
    move-result v0

    .line 207
    const/4 v6, 0x4

    .line 208
    invoke-static {v0, v6}, LX/1dT;->A03(II)Z

    .line 211
    move-result v0

    .line 212
    if-eqz v0, :cond_d9

    .line 214
    invoke-virtual {v1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 217
    :cond_d9
    :goto_d9
    iget-boolean v0, v15, LX/AUy;->A0J:Z

    .line 219
    if-nez v0, :cond_19e

    .line 221
    iget-boolean v0, v2, LX/AUz;->A0W:Z

    .line 223
    if-nez v0, :cond_19e

    .line 225
    iget-object v0, v2, LX/AUz;->A0A:LX/00q;

    .line 227
    invoke-interface {v0}, LX/00q;->get()Ljava/lang/Object;

    .line 230
    move-result-object v1

    .line 231
    check-cast v1, LX/1ph;

    .line 233
    iget-object v0, v2, LX/AUz;->A0H:LX/0wE;

    .line 235
    invoke-virtual {v1, v0}, LX/1ph;->A00(LX/0wE;)Z

    .line 238
    move-result v0

    .line 239
    if-eqz v0, :cond_4f7

    .line 241
    iget-object v12, v15, LX/AUy;->A0E:Lcom/whatsapp/ui/coreui/base/WaTextView;

    .line 243
    if-nez v12, :cond_12c

    .line 245
    invoke-static {v4}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 248
    move-result-object v6

    .line 249
    const v1, 0x7f0e12a4

    .line 252
    const/4 v0, 0x0

    .line 253
    invoke-virtual {v6, v1, v0, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 256
    move-result-object v12

    .line 257
    const-string v0, "null cannot be cast to non-null type com.whatsapp.ui.coreui.base.WaTextView"

    .line 259
    invoke-static {v12, v0}, LX/00C;->A0C(Ljava/lang/Object;Ljava/lang/String;)V

    .line 262
    check-cast v12, Lcom/whatsapp/ui/coreui/base/WaTextView;

    .line 264
    const v0, 0x7f080c95

    .line 267
    invoke-static {v4, v0}, LX/5i8;->A01(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 270
    move-result-object v6

    .line 271
    if-eqz v6, :cond_12c

    .line 273
    invoke-virtual {v12}, Landroid/widget/TextView;->getCurrentTextColor()I

    .line 276
    move-result v0

    .line 277
    invoke-virtual {v6, v0}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 280
    iget-object v1, v2, LX/AUz;->A0G:LX/00V;

    .line 282
    const/4 v0, 0x1

    .line 283
    invoke-static {v6, v12, v1, v0}, LX/0Oz;->A03(Landroid/graphics/drawable/Drawable;Landroid/widget/TextView;LX/00V;Z)V

    .line 286
    invoke-virtual {v12}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 289
    move-result-object v1

    .line 290
    const v0, 0x7f070d48

    .line 293
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 296
    move-result v0

    .line 297
    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    .line 300
    :cond_12c
    iget-object v0, v15, LX/AUy;->A02:Landroid/view/ViewGroup;

    .line 302
    if-nez v0, :cond_19e

    .line 304
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 307
    move-result-object v11

    .line 308
    instance-of v0, v11, Landroid/view/ViewGroup;

    .line 310
    if-eqz v0, :cond_19e

    .line 312
    check-cast v11, Landroid/view/ViewGroup;

    .line 314
    if-eqz v11, :cond_19e

    .line 316
    invoke-virtual {v11, v3}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 319
    move-result v10

    .line 320
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 323
    move-result-object v9

    .line 324
    invoke-virtual {v11, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 327
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 330
    move-result-object v0

    .line 331
    new-instance v8, Landroid/widget/LinearLayout;

    .line 333
    invoke-direct {v8, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 336
    invoke-virtual {v8, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 339
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 342
    move-result-object v0

    .line 343
    invoke-virtual {v8, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 346
    const/16 v6, 0x10

    .line 348
    invoke-virtual {v8, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 351
    invoke-virtual {v8, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 354
    iget-object v0, v2, LX/AUz;->A06:LX/D8k;

    .line 356
    if-eqz v0, :cond_185

    .line 358
    invoke-interface {v0}, LX/D8k;->get()Ljava/lang/Object;

    .line 361
    move-result-object v1

    .line 362
    sget-object v0, LX/AWF;->A04:LX/AWF;

    .line 364
    if-eq v1, v0, :cond_185

    .line 366
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 369
    move-result-object v0

    .line 370
    new-instance v14, Landroid/view/View;

    .line 372
    invoke-direct {v14, v0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 375
    const/4 v13, 0x1

    .line 376
    const/high16 v1, 0x3f800000  # 1.0f

    .line 378
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 380
    invoke-direct {v0, v5, v13, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 383
    invoke-virtual {v14, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 386
    invoke-virtual {v8, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 389
    :cond_185
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 392
    move-result-object v1

    .line 393
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 395
    invoke-direct {v0, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 398
    iput v6, v0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 400
    invoke-virtual {v8, v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 403
    invoke-virtual {v11, v8, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 406
    iput-object v8, v15, LX/AUy;->A02:Landroid/view/ViewGroup;

    .line 408
    iput-object v11, v15, LX/AUy;->A03:Landroid/view/ViewGroup;

    .line 410
    iput-object v9, v15, LX/AUy;->A00:Landroid/view/ViewGroup$LayoutParams;

    .line 412
    iput-object v12, v15, LX/AUy;->A0E:Lcom/whatsapp/ui/coreui/base/WaTextView;

    .line 414
    :cond_19e
    :goto_19e
    invoke-virtual {v15, v4, v3, v2}, LX/AUy;->A02(Landroid/content/Context;Landroid/view/ViewGroup;LX/AUz;)V

    .line 417
    invoke-virtual {v15, v4, v3, v2}, LX/AUy;->A03(Landroid/content/Context;Landroid/view/ViewGroup;LX/AUz;)V

    .line 420
    const/4 v9, 0x1

    .line 421
    iget-boolean v0, v2, LX/AUz;->A0U:Z

    .line 423
    iget-boolean v6, v2, LX/AUz;->A0c:Z

    .line 425
    iget-object v10, v2, LX/AUz;->A0G:LX/00V;

    .line 427
    if-eqz v0, :cond_4f0

    .line 429
    iget-object v8, v15, LX/AUy;->A07:Landroid/widget/ImageView;

    .line 431
    if-nez v8, :cond_1d7

    .line 433
    new-instance v8, Landroid/widget/ImageView;

    .line 435
    invoke-direct {v8, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 438
    iput-object v8, v15, LX/AUy;->A07:Landroid/widget/ImageView;

    .line 440
    invoke-static {}, LX/1hE;->A09()Landroid/widget/LinearLayout$LayoutParams;

    .line 443
    move-result-object v1

    .line 444
    const/16 v0, 0x10

    .line 446
    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 448
    const v21, 0x7f12342c

    .line 451
    invoke-static {v4}, LX/ASv;->A01(Landroid/content/Context;)I

    .line 454
    move-result v22

    .line 455
    move-object/from16 v17, v3

    .line 457
    move-object/from16 v18, v8

    .line 459
    move-object/from16 v19, v10

    .line 461
    move/from16 v20, v9

    .line 463
    move-object/from16 v16, v1

    .line 465
    invoke-virtual/range {v15 .. v22}, LX/AUy;->A04(Landroid/view/ViewGroup$LayoutParams;Landroid/view/ViewGroup;Landroid/widget/ImageView;LX/00V;III)V

    .line 468
    invoke-static {v4, v8, v9, v6}, LX/C3E;->A01(Landroid/content/Context;Landroid/widget/ImageView;IZ)V

    .line 471
    :cond_1d7
    invoke-virtual {v8, v5}, Landroid/view/View;->setVisibility(I)V

    .line 474
    :goto_1da
    iget-boolean v1, v2, LX/AUz;->A0N:Z

    .line 476
    iget-boolean v9, v2, LX/AUz;->A0S:Z

    .line 478
    iget-object v0, v2, LX/AUz;->A09:LX/00q;

    .line 480
    iget-object v8, v2, LX/AUz;->A0E:LX/07A;

    .line 482
    if-eqz v1, :cond_4e9

    .line 484
    invoke-interface {v0}, LX/00q;->get()Ljava/lang/Object;

    .line 487
    move-result-object v0

    .line 488
    check-cast v0, LX/2p5;

    .line 490
    invoke-virtual {v0}, LX/2p5;->A00()Z

    .line 493
    move-result v0

    .line 494
    if-nez v0, :cond_20c

    .line 496
    iget-object v1, v2, LX/AUz;->A0H:LX/0wE;

    .line 498
    instance-of v0, v1, LX/1Xn;

    .line 500
    if-eqz v0, :cond_4e9

    .line 502
    check-cast v1, LX/1Xn;

    .line 504
    iget-object v1, v1, LX/1Xn;->A00:LX/CLp;

    .line 506
    if-eqz v1, :cond_4e9

    .line 508
    const-string v0, "payment_reminder"

    .line 510
    invoke-static {v1, v0}, LX/ASv;->A1Z(LX/CLp;Ljava/lang/String;)Z

    .line 513
    move-result v0

    .line 514
    if-eqz v0, :cond_4e9

    .line 516
    const/16 v0, 0x5fd9

    .line 518
    invoke-virtual {v8, v0}, LX/00I;->A0j(I)Z

    .line 521
    move-result v0

    .line 522
    if-eqz v0, :cond_4e9

    .line 524
    :cond_20c
    if-nez v9, :cond_247

    .line 526
    iget-object v9, v15, LX/AUy;->A06:Landroid/widget/ImageView;

    .line 528
    if-nez v9, :cond_241

    .line 530
    new-instance v9, Landroid/widget/ImageView;

    .line 532
    invoke-direct {v9, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 535
    iput-object v9, v15, LX/AUy;->A06:Landroid/widget/ImageView;

    .line 537
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 540
    move-result-object v1

    .line 541
    const v0, 0x7f071059

    .line 544
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 547
    move-result v0

    .line 548
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 550
    invoke-direct {v1, v0, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 553
    const/16 v0, 0x10

    .line 555
    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 557
    const v21, 0x7f122e1e

    .line 560
    invoke-static {v4}, LX/ASv;->A01(Landroid/content/Context;)I

    .line 563
    move-result v22

    .line 564
    move-object/from16 v16, v1

    .line 566
    move-object/from16 v17, v3

    .line 568
    move-object/from16 v18, v9

    .line 570
    move-object/from16 v19, v10

    .line 572
    move/from16 v20, v5

    .line 574
    invoke-virtual/range {v15 .. v22}, LX/AUy;->A04(Landroid/view/ViewGroup$LayoutParams;Landroid/view/ViewGroup;Landroid/widget/ImageView;LX/00V;III)V

    .line 577
    :cond_241
    invoke-static {v4, v9, v5, v6}, LX/C3E;->A01(Landroid/content/Context;Landroid/widget/ImageView;IZ)V

    .line 580
    invoke-virtual {v9, v5}, Landroid/view/View;->setVisibility(I)V

    .line 583
    :cond_247
    :goto_247
    iget-object v9, v2, LX/AUz;->A0H:LX/0wE;

    .line 585
    invoke-static {}, LX/1hE;->A0Y()LX/0jI;

    .line 588
    move-result-object v0

    .line 589
    invoke-static {v8, v0, v9}, LX/1pV;->A00(LX/07A;LX/0jI;LX/0wE;)Z

    .line 592
    move-result v0

    .line 593
    if-eqz v0, :cond_4e2

    .line 595
    iget-object v11, v15, LX/AUy;->A0B:Landroid/widget/LinearLayout;

    .line 597
    if-nez v11, :cond_271

    .line 599
    invoke-static {v4}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 602
    move-result-object v11

    .line 603
    const v1, 0x7f0e1361

    .line 606
    const/4 v0, 0x0

    .line 607
    invoke-virtual {v11, v1, v0, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 610
    move-result-object v11

    .line 611
    const-string v0, "null cannot be cast to non-null type android.widget.LinearLayout"

    .line 613
    invoke-static {v11, v0}, LX/00C;->A0C(Ljava/lang/Object;Ljava/lang/String;)V

    .line 616
    check-cast v11, Landroid/widget/LinearLayout;

    .line 618
    invoke-virtual {v3, v7}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 621
    move-result v0

    .line 622
    invoke-virtual {v3, v11, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 625
    :cond_271
    const v0, 0x7f0b1864

    .line 628
    invoke-static {v11, v0}, LX/1hB;->A0E(Landroid/view/View;I)Landroid/widget/TextView;

    .line 631
    move-result-object v7

    .line 632
    iget-boolean v1, v2, LX/AUz;->A0R:Z

    .line 634
    const v0, 0x7f123e61

    .line 637
    if-eqz v1, :cond_282

    .line 639
    const v0, 0x7f123e60

    .line 642
    :cond_282
    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setText(I)V

    .line 645
    iput-object v11, v15, LX/AUy;->A0B:Landroid/widget/LinearLayout;

    .line 647
    invoke-virtual {v11, v5}, Landroid/view/View;->setVisibility(I)V

    .line 650
    :goto_28a
    invoke-static {v8}, LX/1hd;->A00(LX/07A;)Z

    .line 653
    move-result v0

    .line 654
    const/16 v7, 0x8

    .line 656
    if-eqz v0, :cond_4d3

    .line 658
    iget-boolean v0, v2, LX/AUz;->A0W:Z

    .line 660
    if-nez v0, :cond_4d3

    .line 662
    iget-object v0, v2, LX/AUz;->A0B:LX/00q;

    .line 664
    invoke-interface {v0}, LX/00q;->get()Ljava/lang/Object;

    .line 667
    move-result-object v1

    .line 668
    check-cast v1, LX/1ik;

    .line 670
    iget-object v0, v2, LX/AUz;->A0D:LX/DER;

    .line 672
    invoke-virtual {v1, v0, v9, v5}, LX/1ik;->A06(LX/DER;LX/0wE;Z)Z

    .line 675
    move-result v0

    .line 676
    if-eqz v0, :cond_4d3

    .line 678
    iget-boolean v0, v2, LX/AUz;->A0O:Z

    .line 680
    if-eqz v0, :cond_4d9

    .line 682
    iget-object v7, v15, LX/AUy;->A0A:Landroid/widget/ImageView;

    .line 684
    if-nez v7, :cond_2d5

    .line 686
    new-instance v7, Landroid/widget/ImageView;

    .line 688
    invoke-direct {v7, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 691
    iput-object v7, v15, LX/AUy;->A0A:Landroid/widget/ImageView;

    .line 693
    invoke-static {}, LX/1hE;->A09()Landroid/widget/LinearLayout$LayoutParams;

    .line 696
    move-result-object v1

    .line 697
    const/16 v0, 0x10

    .line 699
    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 701
    const v21, 0x7f123ce6

    .line 704
    invoke-static {v4}, LX/ASv;->A01(Landroid/content/Context;)I

    .line 707
    move-result v22

    .line 708
    const/4 v0, 0x5

    .line 709
    move-object/from16 v16, v1

    .line 711
    move-object/from16 v17, v3

    .line 713
    move-object/from16 v18, v7

    .line 715
    move-object/from16 v19, v10

    .line 717
    move/from16 v20, v0

    .line 719
    invoke-virtual/range {v15 .. v22}, LX/AUy;->A04(Landroid/view/ViewGroup$LayoutParams;Landroid/view/ViewGroup;Landroid/widget/ImageView;LX/00V;III)V

    .line 722
    invoke-static {v4, v7, v0, v6}, LX/C3E;->A01(Landroid/content/Context;Landroid/widget/ImageView;IZ)V

    .line 725
    :cond_2d5
    invoke-virtual {v7, v5}, Landroid/view/View;->setVisibility(I)V

    .line 728
    :cond_2d8
    :goto_2d8
    iget v13, v2, LX/AUz;->A00:I

    .line 730
    const/16 v8, 0x8

    .line 732
    if-lez v13, :cond_4c7

    .line 734
    iget-wide v0, v2, LX/AUz;->A04:J

    .line 736
    const-wide/16 v11, 0x0

    .line 738
    cmp-long v7, v0, v11

    .line 740
    if-lez v7, :cond_4c7

    .line 742
    iget-object v7, v15, LX/AUy;->A0D:LX/AXb;

    .line 744
    if-nez v7, :cond_331

    .line 746
    invoke-static {v3}, LX/1hD;->A07(Landroid/view/View;)Landroid/content/Context;

    .line 749
    move-result-object v11

    .line 750
    new-instance v7, LX/AXb;

    .line 752
    invoke-direct {v7, v11}, LX/AXb;-><init>(Landroid/content/Context;)V

    .line 755
    iput-object v7, v15, LX/AUy;->A0D:LX/AXb;

    .line 757
    invoke-static {v3}, LX/1hD;->A08(Landroid/view/View;)Landroid/content/res/Resources;

    .line 760
    move-result-object v12

    .line 761
    const v11, 0x7f07009e

    .line 764
    invoke-virtual {v12, v11}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 767
    move-result v11

    .line 768
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    .line 770
    invoke-direct {v12, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 773
    const/16 v11, 0x10

    .line 775
    iput v11, v12, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 777
    invoke-static {v3}, LX/1hD;->A08(Landroid/view/View;)Landroid/content/res/Resources;

    .line 780
    move-result-object v14

    .line 781
    const v11, 0x7f0710af

    .line 784
    invoke-virtual {v14, v11}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 787
    move-result v11

    .line 788
    invoke-virtual {v12, v11}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 791
    invoke-static {v3}, LX/1hD;->A08(Landroid/view/View;)Landroid/content/res/Resources;

    .line 794
    move-result-object v14

    .line 795
    const v11, 0x7f0710a8

    .line 798
    invoke-virtual {v14, v11}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 801
    move-result v11

    .line 802
    invoke-virtual {v12, v11}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 805
    invoke-virtual {v7, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 808
    iget-object v11, v15, LX/AUy;->A0C:Landroid/widget/TextView;

    .line 810
    invoke-virtual {v3, v11}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 813
    move-result v11

    .line 814
    invoke-virtual {v3, v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 817
    :cond_331
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 820
    move-result-object v11

    .line 821
    invoke-static {v11}, LX/ASv;->A02(Landroid/content/Context;)I

    .line 824
    move-result v12

    .line 825
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 828
    move-result-object v11

    .line 829
    invoke-static {v11, v12}, LX/04c;->A00(Landroid/content/Context;I)I

    .line 832
    move-result v11

    .line 833
    invoke-virtual {v7, v11}, LX/AXb;->setColor(I)V

    .line 836
    invoke-virtual {v7, v13}, LX/AXb;->setMaxValueSec(I)V

    .line 839
    iget-object v11, v2, LX/AUz;->A0F:LX/07R;

    .line 841
    invoke-static {v11}, LX/07R;->A00(LX/07R;)J

    .line 844
    move-result-wide v11

    .line 845
    sub-long/2addr v0, v11

    .line 846
    const-wide/16 v12, 0x3e8

    .line 848
    div-long/2addr v0, v12

    .line 849
    long-to-int v11, v0

    .line 850
    if-lt v11, v5, :cond_4bf

    .line 852
    if-lez v11, :cond_4bf

    .line 854
    invoke-virtual {v7, v5}, Landroid/view/View;->setVisibility(I)V

    .line 857
    iget-boolean v0, v7, LX/AXb;->A0A:Z

    .line 859
    const/4 v1, 0x2

    .line 860
    if-eqz v0, :cond_369

    .line 862
    invoke-virtual {v7}, LX/AXb;->getCurrentValueSec()I

    .line 865
    move-result v0

    .line 866
    sub-int/2addr v0, v11

    .line 867
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 870
    move-result v0

    .line 871
    if-le v0, v1, :cond_389

    .line 873
    :cond_369
    invoke-virtual {v7}, LX/AXb;->A00()V

    .line 876
    iget v0, v7, LX/AXb;->A06:I

    .line 878
    int-to-long v0, v0

    .line 879
    mul-long/2addr v0, v12

    .line 880
    iput-wide v0, v7, LX/AXb;->A08:J

    .line 882
    int-to-long v0, v11

    .line 883
    mul-long/2addr v0, v12

    .line 884
    iput-wide v0, v7, LX/AXb;->A07:J

    .line 886
    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    .line 889
    iget-wide v0, v7, LX/AXb;->A07:J

    .line 891
    new-instance v5, LX/AX1;

    .line 893
    invoke-direct {v5, v7, v0, v1}, LX/AX1;-><init>(LX/AXb;J)V

    .line 896
    invoke-virtual {v5}, Landroid/os/CountDownTimer;->start()Landroid/os/CountDownTimer;

    .line 899
    move-result-object v0

    .line 900
    iput-object v0, v7, LX/AXb;->A09:Landroid/os/CountDownTimer;

    .line 902
    const/4 v0, 0x1

    .line 903
    iput-boolean v0, v7, LX/AXb;->A0A:Z

    .line 905
    :cond_389
    :goto_389
    invoke-virtual {v9}, LX/0wE;->A0S()Z

    .line 908
    move-result v0

    .line 909
    if-eqz v0, :cond_427

    .line 911
    const/4 v7, 0x0

    .line 912
    iget-boolean v1, v2, LX/AUz;->A0Y:Z

    .line 914
    iget-object v12, v2, LX/AUz;->A07:LX/00q;

    .line 916
    iget-object v0, v2, LX/AUz;->A0I:LX/6JJ;

    .line 918
    iget-object v13, v2, LX/AUz;->A0L:Ljava/lang/String;

    .line 920
    iget-boolean v14, v2, LX/AUz;->A0T:Z

    .line 922
    const/16 v5, 0x8

    .line 924
    if-nez v1, :cond_431

    .line 926
    iget-object v11, v15, LX/AUy;->A0H:LX/0Rh;

    .line 928
    if-nez v11, :cond_42c

    .line 930
    const v1, 0x7f0b1e3a

    .line 933
    invoke-virtual {v3, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 936
    move-result-object v1

    .line 937
    if-eqz v1, :cond_42a

    .line 939
    invoke-static {v1}, LX/1hB;->A13(Landroid/view/View;)LX/0Rh;

    .line 942
    move-result-object v11

    .line 943
    :goto_3af
    iput-object v11, v15, LX/AUy;->A0H:LX/0Rh;

    .line 945
    if-nez v11, :cond_42c

    .line 947
    :cond_3b3
    :goto_3b3
    iget-object v5, v2, LX/AUz;->A0C:Lcom/google/common/base/Optional;

    .line 949
    invoke-virtual {v5}, Lcom/google/common/base/Optional;->isPresent()Z

    .line 952
    move-result v0

    .line 953
    if-eqz v0, :cond_427

    .line 955
    iget-object v0, v9, LX/0wE;->A0i:LX/1Tc;

    .line 957
    iget-boolean v0, v0, LX/1Tc;->A02:Z

    .line 959
    const v1, 0x7f06067e

    .line 962
    if-eqz v0, :cond_3c7

    .line 964
    const v1, 0x7f060683

    .line 967
    :cond_3c7
    const v0, 0x7f0409c4

    .line 970
    invoke-static {v4, v0, v1}, LX/0Qq;->A00(Landroid/content/Context;II)I

    .line 973
    move-result v2

    .line 974
    iget-object v1, v15, LX/AUy;->A0I:LX/0Rh;

    .line 976
    if-nez v1, :cond_3e1

    .line 978
    const v0, 0x7f0b3352

    .line 981
    invoke-virtual {v3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 984
    move-result-object v0

    .line 985
    if-eqz v0, :cond_428

    .line 987
    invoke-static {v0}, LX/1hB;->A13(Landroid/view/View;)LX/0Rh;

    .line 990
    move-result-object v1

    .line 991
    iput-object v1, v15, LX/AUy;->A0I:LX/0Rh;

    .line 993
    :cond_3e1
    :goto_3e1
    invoke-virtual {v5}, Lcom/google/common/base/Optional;->get()Ljava/lang/Object;

    .line 996
    move-result-object v0

    .line 997
    check-cast v0, LX/6zA;

    .line 999
    invoke-static {v4, v2}, LX/04c;->A00(Landroid/content/Context;I)I

    .line 1002
    move-result v4

    .line 1003
    if-eqz v1, :cond_427

    .line 1005
    iget-object v3, v0, LX/6zA;->A0A:LX/0lW;

    .line 1007
    invoke-virtual {v3}, LX/0lW;->A0G()Z

    .line 1010
    move-result v0

    .line 1011
    if-eqz v0, :cond_427

    .line 1013
    invoke-static {v1}, LX/1hC;->A06(LX/0Rh;)Landroid/view/View;

    .line 1016
    move-result-object v2

    .line 1017
    check-cast v2, Landroid/widget/ImageView;

    .line 1019
    invoke-static {v9}, LX/5ko;->A00(LX/0wE;)LX/7Pv;

    .line 1022
    move-result-object v0

    .line 1023
    if-eqz v0, :cond_567

    .line 1025
    iget-boolean v1, v0, LX/7Pv;->A0D:Z

    .line 1027
    const/4 v0, 0x1

    .line 1028
    if-ne v1, v0, :cond_567

    .line 1030
    iget-object v1, v3, LX/0lW;->A00:LX/07A;

    .line 1032
    const/16 v0, 0x2b36

    .line 1034
    invoke-virtual {v1, v0}, LX/00I;->A0j(I)Z

    .line 1037
    move-result v0

    .line 1038
    if-eqz v0, :cond_567

    .line 1040
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1043
    move-result-object v1

    .line 1044
    const v0, 0x7f080ba0

    .line 1047
    invoke-static {v1, v0}, LX/5i8;->A01(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 1050
    move-result-object v0

    .line 1051
    if-eqz v0, :cond_427

    .line 1053
    invoke-static {v0, v4}, LX/1d4;->A07(Landroid/graphics/drawable/Drawable;I)Landroid/graphics/drawable/Drawable;

    .line 1056
    move-result-object v0

    .line 1057
    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1060
    invoke-virtual {v2, v7}, Landroid/view/View;->setVisibility(I)V

    .line 1063
    :cond_427
    return-void

    .line 1064
    :cond_428
    const/4 v1, 0x0

    .line 1065
    goto :goto_3e1

    .line 1066
    :cond_42a
    const/4 v11, 0x0

    .line 1067
    goto :goto_3af

    .line 1068
    :cond_42c
    if-eqz v14, :cond_437

    .line 1070
    invoke-virtual {v11, v8}, LX/0Rh;->A05(I)V

    .line 1073
    :cond_431
    iget-object v0, v15, LX/AUy;->A09:Landroid/widget/ImageView;

    .line 1075
    if-nez v0, :cond_4ba

    .line 1077
    goto/16 :goto_3b3

    .line 1079
    :cond_437
    if-eqz v0, :cond_431

    .line 1081
    if-eqz v13, :cond_431

    .line 1083
    invoke-static {v12}, LX/1hD;->A1G(LX/00q;)Ljava/lang/Object;

    .line 1086
    move-result-object v1

    .line 1087
    check-cast v1, LX/0lW;

    .line 1089
    const/4 v8, 0x1

    .line 1090
    invoke-static {v1, v8}, LX/00C;->A0A(Ljava/lang/Object;I)V

    .line 1093
    invoke-virtual {v0}, LX/6JJ;->A0j()Z

    .line 1096
    move-result v0

    .line 1097
    if-eqz v0, :cond_431

    .line 1099
    iget-object v1, v1, LX/0lW;->A00:LX/07A;

    .line 1101
    const/16 v0, 0x1271

    .line 1103
    invoke-virtual {v1, v0}, LX/00I;->A0Q(I)I

    .line 1106
    move-result v0

    .line 1107
    if-lt v0, v8, :cond_431

    .line 1109
    invoke-static {v11, v13}, LX/5i3;->A1K(LX/0Rh;Ljava/lang/CharSequence;)V

    .line 1112
    invoke-virtual {v11, v7}, LX/0Rh;->A05(I)V

    .line 1115
    iget-object v11, v15, LX/AUy;->A01:Landroid/view/ViewGroup;

    .line 1117
    invoke-static {v12}, LX/1hD;->A0q(LX/00q;)LX/07A;

    .line 1120
    move-result-object v1

    .line 1121
    const/16 v0, 0x5c40

    .line 1123
    invoke-virtual {v1, v0}, LX/00I;->A0j(I)Z

    .line 1126
    move-result v0

    .line 1127
    if-eqz v0, :cond_4b6

    .line 1129
    iget-object v8, v15, LX/AUy;->A09:Landroid/widget/ImageView;

    .line 1131
    if-nez v8, :cond_4ad

    .line 1133
    new-instance v8, Landroid/widget/ImageView;

    .line 1135
    invoke-direct {v8, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 1138
    iput-object v8, v15, LX/AUy;->A09:Landroid/widget/ImageView;

    .line 1140
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 1143
    move-result-object v1

    .line 1144
    const v0, 0x7f07105d

    .line 1147
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 1150
    move-result v13

    .line 1151
    const v0, 0x7f071079

    .line 1154
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 1157
    move-result v12

    .line 1158
    const v0, 0x7f071077

    .line 1161
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 1164
    move-result v5

    .line 1165
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 1167
    invoke-direct {v1, v13, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1170
    const/16 v0, 0x10

    .line 1172
    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1174
    invoke-virtual {v1, v12}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 1177
    iput v5, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 1179
    const v21, 0x7f123c94

    .line 1182
    const/16 v20, 0x6

    .line 1184
    move-object/from16 v16, v1

    .line 1186
    move-object/from16 v17, v11

    .line 1188
    move-object/from16 v18, v8

    .line 1190
    move-object/from16 v19, v10

    .line 1192
    move/from16 v22, v7

    .line 1194
    invoke-virtual/range {v15 .. v22}, LX/AUy;->A04(Landroid/view/ViewGroup$LayoutParams;Landroid/view/ViewGroup;Landroid/widget/ImageView;LX/00V;III)V

    .line 1197
    :cond_4ad
    const/4 v0, 0x6

    .line 1198
    invoke-static {v4, v8, v0, v6}, LX/C3E;->A01(Landroid/content/Context;Landroid/widget/ImageView;IZ)V

    .line 1201
    invoke-virtual {v8, v7}, Landroid/view/View;->setVisibility(I)V

    .line 1204
    goto/16 :goto_3b3

    .line 1206
    :cond_4b6
    iget-object v0, v15, LX/AUy;->A09:Landroid/widget/ImageView;

    .line 1208
    if-eqz v0, :cond_3b3

    .line 1210
    :cond_4ba
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    .line 1213
    goto/16 :goto_3b3

    .line 1215
    :cond_4bf
    invoke-virtual {v7}, LX/AXb;->A00()V

    .line 1218
    invoke-virtual {v7, v8}, Landroid/view/View;->setVisibility(I)V

    .line 1221
    goto/16 :goto_389

    .line 1223
    :cond_4c7
    iget-object v0, v15, LX/AUy;->A0D:LX/AXb;

    .line 1225
    if-eqz v0, :cond_389

    .line 1227
    invoke-virtual {v0}, LX/AXb;->A00()V

    .line 1230
    invoke-virtual {v0, v8}, Landroid/view/View;->setVisibility(I)V

    .line 1233
    goto/16 :goto_389

    .line 1235
    :cond_4d3
    iget-object v0, v15, LX/AUy;->A0A:Landroid/widget/ImageView;

    .line 1237
    if-nez v0, :cond_4dd

    .line 1239
    goto/16 :goto_2d8

    .line 1241
    :cond_4d9
    iget-object v0, v15, LX/AUy;->A0A:Landroid/widget/ImageView;

    .line 1243
    if-eqz v0, :cond_2d8

    .line 1245
    :cond_4dd
    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    .line 1248
    goto/16 :goto_2d8

    .line 1250
    :cond_4e2
    iget-object v0, v15, LX/AUy;->A0B:Landroid/widget/LinearLayout;

    .line 1252
    invoke-static {v0}, LX/1hF;->A18(Landroid/view/View;)V

    .line 1255
    goto/16 :goto_28a

    .line 1257
    :cond_4e9
    iget-object v0, v15, LX/AUy;->A06:Landroid/widget/ImageView;

    .line 1259
    invoke-static {v0}, LX/1hF;->A18(Landroid/view/View;)V

    .line 1262
    goto/16 :goto_247

    .line 1264
    :cond_4f0
    iget-object v0, v15, LX/AUy;->A07:Landroid/widget/ImageView;

    .line 1266
    invoke-static {v0}, LX/1hF;->A18(Landroid/view/View;)V

    .line 1269
    goto/16 :goto_1da

    .line 1271
    :cond_4f7
    iget-object v1, v15, LX/AUy;->A02:Landroid/view/ViewGroup;

    .line 1273
    if-eqz v1, :cond_19e

    .line 1275
    iget-object v8, v15, LX/AUy;->A03:Landroid/view/ViewGroup;

    .line 1277
    if-eqz v8, :cond_19e

    .line 1279
    invoke-virtual {v8, v1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 1282
    move-result v6

    .line 1283
    iget-object v0, v15, LX/AUy;->A01:Landroid/view/ViewGroup;

    .line 1285
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 1288
    invoke-virtual {v8, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 1291
    iget-object v1, v15, LX/AUy;->A01:Landroid/view/ViewGroup;

    .line 1293
    iget-object v0, v15, LX/AUy;->A00:Landroid/view/ViewGroup$LayoutParams;

    .line 1295
    invoke-virtual {v8, v1, v6, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 1298
    const/4 v0, 0x0

    .line 1299
    iput-object v0, v15, LX/AUy;->A02:Landroid/view/ViewGroup;

    .line 1301
    iput-object v0, v15, LX/AUy;->A03:Landroid/view/ViewGroup;

    .line 1303
    iput-object v0, v15, LX/AUy;->A00:Landroid/view/ViewGroup$LayoutParams;

    .line 1305
    iput-object v0, v15, LX/AUy;->A0E:Lcom/whatsapp/ui/coreui/base/WaTextView;

    .line 1307
    goto/16 :goto_19e

    .line 1309
    :cond_51d
    const/4 v0, 0x2

    .line 1310
    if-ne v8, v0, :cond_527

    .line 1312
    const/16 v0, 0x8

    .line 1314
    const v8, 0x7f121e99

    .line 1317
    if-eq v9, v0, :cond_bb

    .line 1319
    :cond_527
    const v8, 0x7f121eab

    .line 1322
    goto/16 :goto_bb

    .line 1324
    :cond_52c
    const/4 v0, 0x5

    .line 1325
    invoke-static {v9, v0}, LX/1dT;->A03(II)Z

    .line 1328
    move-result v0

    .line 1329
    if-eqz v0, :cond_538

    .line 1331
    const v8, 0x7f121e87

    .line 1334
    goto/16 :goto_bb

    .line 1336
    :cond_538
    const/4 v0, 0x4

    .line 1337
    const v8, 0x7f121e96

    .line 1340
    if-ne v9, v0, :cond_bb

    .line 1342
    const v8, 0x7f121eb0

    .line 1345
    goto/16 :goto_bb

    .line 1347
    :cond_543
    invoke-static {v4, v0}, LX/04c;->A03(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 1350
    move-result-object v0

    .line 1351
    goto/16 :goto_9f

    .line 1353
    :cond_549
    const v9, 0x7f08087f

    .line 1356
    goto/16 :goto_8a

    .line 1358
    :cond_54e
    iget-object v0, v15, LX/AUy;->A08:Landroid/widget/ImageView;

    .line 1360
    invoke-static {v0}, LX/1hF;->A19(Landroid/view/View;)V

    .line 1363
    goto/16 :goto_d9

    .line 1365
    :cond_555
    invoke-virtual {v7, v5}, Landroid/view/View;->setVisibility(I)V

    .line 1368
    iget-object v8, v2, LX/AUz;->A0G:LX/00V;

    .line 1370
    iget-object v6, v2, LX/AUz;->A0F:LX/07R;

    .line 1372
    iget-wide v0, v2, LX/AUz;->A05:J

    .line 1374
    invoke-static {v6, v8, v0, v1}, LX/AVX;->A00(LX/07R;LX/00V;J)Ljava/lang/String;

    .line 1377
    move-result-object v0

    .line 1378
    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1381
    goto/16 :goto_1d

    .line 1383
    :cond_567
    const/16 v0, 0x8

    .line 1385
    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 1388
    return-void
.end method

.method public final A02(Landroid/content/Context;Landroid/view/ViewGroup;LX/AUz;)V
    .registers 16

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/00C;->A0A(Ljava/lang/Object;I)V

    .line 4
    const/4 v2, 0x1

    .line 5
    iget-boolean v1, p3, LX/AUz;->A0c:Z

    .line 7
    iget v0, p3, LX/AUz;->A02:I

    .line 9
    iget-object v8, p3, LX/AUz;->A0G:LX/00V;

    .line 11
    move-object v4, p0

    .line 12
    if-ne v2, v0, :cond_35

    .line 14
    iget-object v7, p0, LX/AUy;->A04:Landroid/widget/ImageView;

    .line 16
    if-nez v7, :cond_2d

    .line 18
    new-instance v7, Landroid/widget/ImageView;

    .line 20
    invoke-direct {v7, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 23
    iput-object v7, p0, LX/AUy;->A04:Landroid/widget/ImageView;

    .line 25
    invoke-static {}, LX/1hE;->A09()Landroid/widget/LinearLayout$LayoutParams;

    .line 28
    move-result-object v5

    .line 29
    const/16 v0, 0x10

    .line 31
    iput v0, v5, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 33
    const v10, 0x7f121bb9

    .line 36
    invoke-static {p1}, LX/ASv;->A01(Landroid/content/Context;)I

    .line 39
    move-result v11

    .line 40
    const/4 v9, 0x2

    .line 41
    move-object v6, p2

    .line 42
    invoke-virtual/range {v4 .. v11}, LX/AUy;->A04(Landroid/view/ViewGroup$LayoutParams;Landroid/view/ViewGroup;Landroid/widget/ImageView;LX/00V;III)V

    .line 45
    :cond_2d
    const/4 v0, 0x2

    .line 46
    invoke-static {p1, v7, v0, v1}, LX/C3E;->A01(Landroid/content/Context;Landroid/widget/ImageView;IZ)V

    .line 49
    invoke-virtual {v7, v3}, Landroid/view/View;->setVisibility(I)V

    .line 52
    return-void

    .line 53
    :cond_35
    iget-object v0, p0, LX/AUy;->A04:Landroid/widget/ImageView;

    .line 55
    invoke-static {v0}, LX/1hF;->A18(Landroid/view/View;)V

    .line 58
    return-void
.end method

.method public final A03(Landroid/content/Context;Landroid/view/ViewGroup;LX/AUz;)V
    .registers 16

    .line 0
    const/4 v3, 0x0

    .line 1
    invoke-static {p1, v3}, LX/00C;->A0A(Ljava/lang/Object;I)V

    .line 4
    const/4 v2, 0x1

    .line 5
    iget v0, p3, LX/AUz;->A03:I

    .line 7
    iget-boolean v1, p3, LX/AUz;->A0c:Z

    .line 9
    iget-object v8, p3, LX/AUz;->A0G:LX/00V;

    .line 11
    move-object v4, p0

    .line 12
    if-ne v0, v2, :cond_35

    .line 14
    iget-object v7, p0, LX/AUy;->A05:Landroid/widget/ImageView;

    .line 16
    if-nez v7, :cond_2d

    .line 18
    new-instance v7, Landroid/widget/ImageView;

    .line 20
    invoke-direct {v7, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 23
    iput-object v7, p0, LX/AUy;->A05:Landroid/widget/ImageView;

    .line 25
    invoke-static {}, LX/1hE;->A09()Landroid/widget/LinearLayout$LayoutParams;

    .line 28
    move-result-object v5

    .line 29
    const/16 v0, 0x10

    .line 31
    iput v0, v5, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 33
    const v10, 0x7f122b27

    .line 36
    invoke-static {p1}, LX/ASv;->A01(Landroid/content/Context;)I

    .line 39
    move-result v11

    .line 40
    const/4 v9, 0x3

    .line 41
    move-object v6, p2

    .line 42
    invoke-virtual/range {v4 .. v11}, LX/AUy;->A04(Landroid/view/ViewGroup$LayoutParams;Landroid/view/ViewGroup;Landroid/widget/ImageView;LX/00V;III)V

    .line 45
    :cond_2d
    const/4 v0, 0x3

    .line 46
    invoke-static {p1, v7, v0, v1}, LX/C3E;->A01(Landroid/content/Context;Landroid/widget/ImageView;IZ)V

    .line 49
    invoke-virtual {v7, v3}, Landroid/view/View;->setVisibility(I)V

    .line 52
    return-void

    .line 53
    :cond_35
    iget-object v0, p0, LX/AUy;->A05:Landroid/widget/ImageView;

    .line 55
    invoke-static {v0}, LX/1hF;->A18(Landroid/view/View;)V

    .line 58
    return-void
.end method

.method public final A04(Landroid/view/ViewGroup$LayoutParams;Landroid/view/ViewGroup;Landroid/widget/ImageView;LX/00V;III)V
    .registers 17

    .line 0
    const/4 v1, 0x0

    .line 1
    invoke-virtual {p3, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 4
    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0, p3, p6}, LX/1hD;->A1P(Landroid/content/Context;Landroid/view/View;I)V

    .line 11
    move/from16 v0, p7

    .line 13
    invoke-static {p3, p4, v1, v0}, LX/0Oz;->A08(Landroid/view/View;LX/00V;II)V

    .line 16
    iget-object v2, p0, LX/AUy;->A06:Landroid/widget/ImageView;

    .line 18
    iget-object v3, p0, LX/AUy;->A07:Landroid/widget/ImageView;

    .line 20
    iget-object v4, p0, LX/AUy;->A04:Landroid/widget/ImageView;

    .line 22
    iget-object v5, p0, LX/AUy;->A05:Landroid/widget/ImageView;

    .line 24
    iget-object v6, p0, LX/AUy;->A0A:Landroid/widget/ImageView;

    .line 26
    iget-object v7, p0, LX/AUy;->A09:Landroid/widget/ImageView;

    .line 28
    move v8, p5

    .line 29
    invoke-static/range {v2 .. v8}, LX/C3E;->A00(Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;I)I

    .line 32
    move-result v0

    .line 33
    if-eqz p2, :cond_29

    .line 35
    invoke-virtual {p2, p3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 38
    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 41
    :cond_29
    return-void
.end method
